const renderSection = (section, index) => {
  if (!section || !section.items?.length) return null;

  return (
    <section key={`${section.title}-${index}`} className="break-inside-avoid">
      <h3 className="mb-2 border-b-[2px] border-black pb-1 text-[11px] font-black uppercase tracking-[0.18em] text-gray-700">
        {section.title}
      </h3>

      {section.title === "Summary" ? (
        <p className="text-sm leading-6 text-gray-800">{section.items.join(" ")}</p>
      ) : (
        <ul className="space-y-2 pl-5 text-sm leading-6 text-gray-800">
          {section.items.map((item, itemIndex) => (
            <li key={`${section.title}-${itemIndex}`} className="list-disc marker:text-gray-600">
              {item}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
};

export default function ATSClassicTemplate({ document }) {
  const sections = document?.sections || [];

  return (
    <div className="min-h-[1100px] bg-white p-8 text-gray-900">
      <header className="mb-7 border-b-[2px] border-black pb-4">
        <h1 className="text-3xl font-black tracking-[-0.04em] text-black">
          {document?.name || "Resume Candidate"}
        </h1>

        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[11px] font-semibold uppercase tracking-[0.12em] text-gray-700">
          {document?.email && <span>{document.email}</span>}
          {document?.phone && <span>{document.phone}</span>}
          {document?.location && <span>{document.location}</span>}
          {document?.website && <span>{document.website}</span>}
        </div>
      </header>

      <div className="space-y-6">
        {sections.map((section, index) => renderSection(section, index))}
      </div>
    </div>
  );
}
