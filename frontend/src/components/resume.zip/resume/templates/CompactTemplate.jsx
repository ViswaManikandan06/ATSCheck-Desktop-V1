const renderSection = (section, index) => {
  if (!section || !section.items?.length) return null;

  return (
    <section key={`${section.title}-${index}`} className="break-inside-avoid">
      <h3 className="mb-2 text-[10px] font-black uppercase tracking-[0.18em] text-slate-600">
        {section.title}
      </h3>

      {section.title === "Summary" ? (
        <p className="text-[13px] leading-5 text-slate-700">{section.items.join(" ")}</p>
      ) : (
        <ul className="space-y-1.5 pl-4 text-[13px] leading-5 text-slate-700">
          {section.items.map((item, itemIndex) => (
            <li key={`${section.title}-${itemIndex}`} className="list-disc marker:text-slate-500">
              {item}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
};

export default function CompactTemplate({ document }) {
  const sections = document?.sections || [];

  return (
    <div className="min-h-[1100px] bg-white p-6 text-slate-800">
      <header className="mb-5 border-b-[2px] border-slate-500 pb-3">
        <h1 className="text-[26px] font-black tracking-[-0.04em] text-slate-900">
          {document?.name || "Resume Candidate"}
        </h1>

        <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-600">
          {document?.email && <span>{document.email}</span>}
          {document?.phone && <span>{document.phone}</span>}
          {document?.location && <span>{document.location}</span>}
          {document?.website && <span>{document.website}</span>}
        </div>
      </header>

      <div className="space-y-4">
        {sections.map((section, index) => renderSection(section, index))}
      </div>
    </div>
  );
}
