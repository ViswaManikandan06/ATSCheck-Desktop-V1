const renderSection = (section, index) => {
  if (!section || !section.items?.length) return null;

  return (
    <section key={`${section.title}-${index}`} className="break-inside-avoid">
      <div className="mb-3 border-b-[2px] border-gray-300 pb-1">
        <h3 className="text-[12px] font-black uppercase tracking-[0.18em] text-slate-700">
          {section.title}
        </h3>
      </div>

      {section.title === "Summary" ? (
        <p className="text-sm leading-6 text-slate-700">{section.items.join(" ")}</p>
      ) : (
        <ul className="space-y-2 text-sm leading-6 text-slate-700">
          {section.items.map((item, itemIndex) => (
            <li key={`${section.title}-${itemIndex}`} className="list-disc pl-5 marker:text-slate-500">
              {item}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
};

export default function ModernProfessionalTemplate({ document }) {
  const sections = document?.sections || [];

  return (
    <div className="min-h-[1100px] bg-[#f8fafc] p-8 text-slate-800">
      <header className="mb-7 border-l-[4px] border-slate-900 bg-white p-5 shadow-sm">
        <h1 className="text-3xl font-black tracking-[-0.04em] text-slate-900">
          {document?.name || "Resume Candidate"}
        </h1>

        <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-600">
          {document?.email && <span>{document.email}</span>}
          {document?.phone && <span>{document.phone}</span>}
          {document?.location && <span>{document.location}</span>}
          {document?.website && <span>{document.website}</span>}
        </div>
      </header>

      <div className="space-y-6">
        {sections.map((section, index) => renderSection(section, index))}
      </div>
    </div>
  );
}
